package smartdream.app.wallet

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import smartdream.app.R
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import androidx.compose.runtime.LaunchedEffect

@Composable
fun WalletScreen(navController: NavController) {
        val amount = remember { mutableStateOf("") }
    val upiId = remember { mutableStateOf("") }
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val user = auth.currentUser
    val walletBalance = remember { mutableStateOf(0.0) }

    LaunchedEffect(user) {
        user?.let {
            db.collection("users").document(it.uid).get()
                .addOnSuccessListener { document ->
                    if (document != null) {
                        walletBalance.value = document.getDouble("walletBalance") ?: 0.0
                    }
                }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(R.string.your_balance, walletBalance.value))
        TextField(
            value = amount.value,
            onValueChange = { amount.value = it },
            label = { Text(stringResource(R.string.amount_min_1)) }
        )
        TextField(
            value = upiId.value,
            onValueChange = { upiId.value = it },
            label = { Text(stringResource(R.string.upi_id)) }
        )
                Button(onClick = {
            val withdrawalRequest = hashMapOf(
                "userId" to user?.uid,
                "userName" to user?.displayName,
                "upiId" to upiId.value,
                "amount" to amount.value.toDouble(),
                "status" to "pending"
            )
            db.collection("withdrawals").add(withdrawalRequest)
        }) {
            Text(stringResource(R.string.submit_withdrawal))
        }
    }
}
