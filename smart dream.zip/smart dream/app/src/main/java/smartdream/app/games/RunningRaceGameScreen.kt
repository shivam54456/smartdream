package smartdream.app.games

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import smartdream.app.R
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import android.media.SoundPool
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import smartdream.app.showInterstitialAd

@Composable
fun RunningRaceGameScreen(navController: NavController) {
    val activity = LocalContext.current as android.app.Activity
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val user = auth.currentUser

    var playerY by remember { mutableStateOf(0f) }
    var obstacleX by remember { mutableStateOf(1000f) }
    var isJumping by remember { mutableStateOf(false) }
    var gameOver by remember { mutableStateOf(false) }

    val animatedPlayerY by animateFloatAsState(targetValue = playerY, animationSpec = tween(300))
    val animatedObstacleX by animateFloatAsState(targetValue = obstacleX, animationSpec = tween(0))

    val context = LocalContext.current
    val soundPool = remember {
        SoundPool.Builder().setMaxStreams(2).build()
    }
    val jumpSound = remember { soundPool.load(context, R.raw.jump, 1) }
    val crashSound = remember { soundPool.load(context, R.raw.crash, 1) }

    LaunchedEffect(Unit) {
        while (!gameOver) {
            obstacleX -= 20f
            if (obstacleX < -100f) {
                obstacleX = 1000f
            }

            // Collision detection
            if (obstacleX < 150 && obstacleX > 50 && playerY > -50) {
                gameOver = true
                soundPool.play(crashSound, 1f, 1f, 0, 0, 1f)
            }
            delay(16)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            soundPool.release()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Player
        Box(
            modifier = Modifier
                .size(50.dp)
                .align(Alignment.BottomStart)
                .offset(x = 50.dp, y = animatedPlayerY.dp)
                .background(Color.Green)
        )

        // Obstacle
        Box(
            modifier = Modifier
                .size(50.dp, 100.dp)
                .align(Alignment.BottomStart)
                .offset(x = animatedObstacleX.dp, y = 0.dp)
                .background(Color.Red)
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (gameOver) {
                Text("Game Over", color = Color.Red)
                Button(onClick = {
                    showInterstitialAd(activity) {
                        user?.let {
                            db.collection("users").document(it.uid)
                                .update("walletBalance", com.google.firebase.firestore.FieldValue.increment(0.10))
                        }
                        navController.popBackStack()
                    }
                }) {
                    Text(stringResource(R.string.finish_game))
                }
            } else {
                Button(onClick = {
                    if (!isJumping) {
                        isJumping = true
                        playerY = -150f
                        soundPool.play(jumpSound, 1f, 1f, 0, 0, 1f)
                        // Come back down
                        kotlinx.coroutines.GlobalScope.launch {
                            delay(300)
                            playerY = 0f
                            delay(300)
                            isJumping = false
                        }
                    }
                }) {
                    Text("Jump")
                }
            }
        }
    }
}
