package smartdream.app.games

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import smartdream.app.R
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import android.media.SoundPool
import kotlin.random.Random
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import smartdream.app.showInterstitialAd

@Composable
fun CarRacingGameScreen(navController: NavController) {
    val activity = LocalContext.current as android.app.Activity
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val user = auth.currentUser

    var playerX by remember { mutableStateOf(150f) }
    val obstacles = remember { mutableStateListOf<Pair<Float, Float>>() }
    var gameOver by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val soundPool = remember {
        SoundPool.Builder().setMaxStreams(1).build()
    }
    val crashSound = remember { soundPool.load(context, R.raw.crash, 1) }

    LaunchedEffect(Unit) {
        // Add initial obstacle
        obstacles.add(Pair(Random.nextInt(0, 300).toFloat(), -100f))

        while (!gameOver) {
            // Move obstacles down
            val newObstacles = obstacles.map { Pair(it.first, it.second + 20f) }.toMutableList()
            obstacles.clear()
            obstacles.addAll(newObstacles.filter { it.second < 800f })

            // Add new obstacle periodically
            if (obstacles.last().second > 250f) {
                obstacles.add(Pair(Random.nextInt(50, 250).toFloat(), -100f))
            }

            // Collision detection
            obstacles.forEach { obstacle ->
                if (obstacle.second > 600 && obstacle.second < 750 &&
                    (playerX - obstacle.first).let { it > -50 && it < 50 })
                {
                    gameOver = true
                    soundPool.play(crashSound, 1f, 1f, 0, 0, 1f)
                }
            }

            delay(32)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            soundPool.release()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Gray)) {
        // Player Car
        Box(
            modifier = Modifier
                .size(50.dp, 100.dp)
                .align(Alignment.BottomCenter)
                .offset(x = (playerX - 150).dp, y = (-50).dp)
                .background(Color.Blue)
        )

        // Obstacle Cars
        obstacles.forEach { (x, y) ->
            Box(
                modifier = Modifier
                    .size(50.dp, 100.dp)
                    .align(Alignment.TopCenter)
                    .offset(x = (x - 150).dp, y = y.dp)
                    .background(Color.Red)
            )
        }

        if (gameOver) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Game Over", color = Color.White)
                Button(onClick = {
                    showInterstitialAd(activity) {
                        user?.let {
                            db.collection("users").document(it.uid)
                                .update("walletBalance", com.google.firebase.firestore.FieldValue.increment(0.10))
                        }
                        navController.popBackStack()
                    }
                }) {
                    Text(stringResource(R.string.finish_game))
                }
            }
        } else {
             Row(
                modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(onClick = { if(playerX > 50) playerX -= 50f }) { Text("Left") }
                Button(onClick = { if(playerX < 250) playerX += 50f }) { Text("Right") }
            }
        }
    }
}
