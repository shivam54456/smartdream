package smartdream.app.games

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import smartdream.app.R
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.media.SoundPool
import androidx.compose.runtime.DisposableEffect
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import smartdream.app.showInterstitialAd

@Composable
fun OxGameScreen(navController: NavController) {
    val activity = LocalContext.current as android.app.Activity
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val user = auth.currentUser

    var board by remember { mutableStateOf(List(9) { "" }) }
    var isPlayerTurn by remember { mutableStateOf(true) }
    var winner by remember { mutableStateOf("") }

    val context = LocalContext.current
    val soundPool = remember {
        SoundPool.Builder().setMaxStreams(4).build()
    }
    val moveSound = remember { soundPool.load(context, R.raw.move, 1) }
    val winSound = remember { soundPool.load(context, R.raw.win, 1) }
    val loseSound = remember { soundPool.load(context, R.raw.lose, 1) }
    val drawSound = remember { soundPool.load(context, R.raw.draw, 1) }

    DisposableEffect(Unit) {
        onDispose {
            soundPool.release()
        }
    }

    fun checkWinner(): String {
        val lines = listOf(
            listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
            listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
            listOf(0, 4, 8), listOf(2, 4, 6)
        )
        for (line in lines) {
            val (a, b, c) = line
            if (board[a].isNotEmpty() && board[a] == board[b] && board[a] == board[c]) {
                soundPool.play(if (board[a] == "X") winSound else loseSound, 1f, 1f, 0, 0, 1f)
                return board[a]
            }
        }
        if (board.all { it.isNotEmpty() }) {
            soundPool.play(drawSound, 1f, 1f, 0, 0, 1f)
            return "Draw"
        }
        return ""
    }

    fun botMove() {
        if (winner.isEmpty()) {
            val emptyCells = board.indices.filter { board[it].isEmpty() }
            if (emptyCells.isNotEmpty()) {
                val move = emptyCells.random()
                                board = board.toMutableList().also { it[move] = "O" }
                soundPool.play(moveSound, 1f, 1f, 0, 0, 1f)
                isPlayerTurn = true
                winner = checkWinner()
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(R.string.ox_game), fontSize = 32.sp, modifier = Modifier.padding(bottom = 16.dp))

        LazyVerticalGrid(columns = GridCells.Fixed(3)) {
            items(9) { index ->
                Button(
                    onClick = {
                        if (board[index].isEmpty() && isPlayerTurn && winner.isEmpty()) {
                                                        board = board.toMutableList().also { it[index] = "X" }
                            soundPool.play(moveSound, 1f, 1f, 0, 0, 1f)
                            isPlayerTurn = false
                            winner = checkWinner()
                            if(winner.isEmpty()) botMove()
                        }
                    },
                    modifier = Modifier.padding(8.dp).size(80.dp),
                ) {
                    Text(board[index], fontSize = 32.sp)
                }
            }
        }

        if (winner.isNotEmpty()) {
            val message = when (winner) {
                "X" -> "आप जीत गए!"
                "O" -> "बॉट जीत गया!"
                else -> "गेम ड्रा हो गया!"
            }
            Text(message, fontSize = 24.sp, modifier = Modifier.padding(top = 16.dp))

            Button(onClick = {
                showInterstitialAd(activity) {
                    user?.let {
                        db.collection("users").document(it.uid)
                            .update("walletBalance", com.google.firebase.firestore.FieldValue.increment(0.10))
                    }
                    navController.popBackStack()
                }
            }, modifier = Modifier.padding(top = 16.dp)) {
                Text(stringResource(R.string.finish_game))
            }
        }
    }
}
