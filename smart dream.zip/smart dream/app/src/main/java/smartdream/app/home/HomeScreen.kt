package smartdream.app.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import smartdream.app.R
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember

@Composable
fun HomeScreen(navController: NavController) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val user = auth.currentUser
    val walletBalance = remember { mutableStateOf(0.0) }

    LaunchedEffect(user) {
        user?.let {
            db.collection("users").document(it.uid).get()
                .addOnSuccessListener { document ->
                    if (document != null) {
                        walletBalance.value = document.getDouble("walletBalance") ?: 0.0
                    }
                }
        }
    }
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
            Text(stringResource(R.string.wallet_balance, walletBalance.value))
        Button(onClick = { navController.navigate("wallet") }) {
            Text(stringResource(R.string.go_to_wallet))
        }
        Button(onClick = { navController.navigate("settings") }) {
            Text(stringResource(R.string.go_to_settings))
        }
        Text(stringResource(R.string.games_section))
                Button(onClick = { navController.navigate("running_race_game") }) {
            Text(stringResource(R.string.running_race_game))
        }
                Button(onClick = { navController.navigate("car_racing_game") }) {
            Text(stringResource(R.string.car_racing_game))
        }
                Button(onClick = { navController.navigate("ox_game") }) {
            Text(stringResource(R.string.ox_game))
        }
        // Banner Ad placeholder
                AndroidView(
            factory = {
                AdView(it).apply {
                    setAdSize(AdSize.BANNER)
                    adUnitId = "ca-app-pub-8106985939116099/4303049658"
                    loadAd(AdRequest.Builder().build())
                }
            }
        )
    }
}
