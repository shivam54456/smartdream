package smartdream.app

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import smartdream.app.auth.LoginScreen
import smartdream.app.auth.SignupScreen
import smartdream.app.home.HomeScreen
import smartdream.app.wallet.WalletScreen
import smartdream.app.settings.SettingsScreen
import smartdream.app.games.RunningRaceGameScreen
import smartdream.app.games.CarRacingGameScreen
import smartdream.app.games.OxGameScreen

@Composable
fun Navigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "login") {
        composable("login") { LoginScreen(navController = navController) }
        composable("signup") { SignupScreen(navController = navController) }
        composable("home") { HomeScreen(navController = navController) }
        composable("wallet") { WalletScreen(navController = navController) }
                composable("settings") { SettingsScreen(navController = navController) }
        composable("running_race_game") { RunningRaceGameScreen(navController = navController) }
        composable("car_racing_game") { CarRacingGameScreen(navController = navController) }
        composable("ox_game") { OxGameScreen(navController = navController) }
    }
}
