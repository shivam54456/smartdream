// Replace with your Firebase project's configuration
const firebaseConfig = {
    apiKey: "AIzaSyAaq_ugDjz5ZZGjjIeWuqqmZyBRCR1qmks",
    authDomain: "smartdream-3d552.firebaseapp.com",
    projectId: "smartdream-3d552",
    storageBucket: "smartdream-3d552.appspot.com",
    messagingSenderId: "941668888849",
    appId: "1:941668888849:web:d4f24cf3c9ba1b7f2cdcb0"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
